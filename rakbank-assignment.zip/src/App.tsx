import React from "react";
import "./App.css";
import Slider from "./components/Slider";

function App() {
    return <Slider />;
}

export default App;
